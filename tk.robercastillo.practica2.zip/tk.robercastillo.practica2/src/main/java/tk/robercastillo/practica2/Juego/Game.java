package tk.robercastillo.practica2.Juego;

import tk.robercastillo.practica2.Objetos.Boleto;
import tk.robercastillo.practica2.Objetos.BomboG;

import java.util.Scanner;

public class Game {
    private static Scanner lec = new Scanner(System.in);
    public Game(String boleto, int juego) {
        Boleto boletoJugador = new Boleto(boleto);
        BomboG bomboGrande = new BomboG();          //Creamos los objetos que vamos a usar

        switch (juego) {
            case 1:
                juegoUnico(boletoJugador, bomboGrande);
                break;
            case 2:
                juegoHastaPremio(boletoJugador, bomboGrande);
                break;
            case 3:
                juegoHastaPremioSinR(boletoJugador, bomboGrande);
                break;
            case 4:
                juego10000(boletoJugador, bomboGrande);
                break;
            case 5:
                juegoPremioEsp(boletoJugador, bomboGrande);
                break;
        }

    }
    public void juegoUnico(Boleto jugador, BomboG bomboG) {
        Boleto premio;
        int aux;
        String ganador="";
        int aciertos=0;
        boolean reintegro=false;

        for (int i=0;i<jugador.lenght();i++) {      //Creamos el boleto ganador
            aux = bomboG.sacarNumero();
            ganador=ganador+aux+" ";
        }
        premio= new Boleto(ganador);

        jugador.ordenarBoleto();        //Ordenamos el array de los 2 boletos
        premio.ordenarBoleto();

        for (int i=0;i<premio.lenght();i++) {       //Comprobamos quien los aciertos que hemos tenido
            for (int j = 0; j < jugador.lenght(); j++) {
                if (premio.getNumBoleto(i) == jugador.getNumBoleto(j)) {
                    aciertos++;
                }
            }
        }
        reintegro = jugador.getReintegro()==premio.getReintegro();
        premios(aciertos, premio, jugador, reintegro);
        continuar();
        borrarPantalla();


    }
    public void juegoHastaPremio(Boleto jugador, BomboG bomboG) {
        Boleto premio;
        int aux;
        String ganador;
        int aciertos;
        int rondas=0;
        boolean reintegro=false;

        do{                                 //Haremos lo mismo de antes pero
            ganador="";                     //esta vez no pararemos hasta obtener un premio
            aciertos=0;
            bomboG.rellenarBombo();

            for (int i=0;i<jugador.lenght();i++) {
                aux = bomboG.sacarNumero();
                ganador=ganador+aux+" ";
            }
            premio= new Boleto(ganador);

            jugador.ordenarBoleto();
            premio.ordenarBoleto();

            for (int i=0;i<premio.lenght();i++) {
                for (int j = 0; j < jugador.lenght(); j++) {
                    if (premio.getNumBoleto(i) == jugador.getNumBoleto(j)) {
                        aciertos++;
                    }
                }
            }
            rondas++;
        }while(aciertos<3);
        System.out.println("Ha tardado "+rondas+" ronda/s en conseguir un premio");
        reintegro = jugador.getReintegro()==premio.getReintegro();

        premios(aciertos, premio, jugador, reintegro);
        continuar();
        borrarPantalla();


    }
    public void juegoHastaPremioSinR(Boleto jugador, BomboG bomboG) {
        Boleto premio;
        int aux;
        String ganador;
        int aciertos;
        int rondas=0;
        boolean reintegro=false;

        do{                         //Haremos lo mismo que el metodo anterior,
            ganador="";             //pero esta vez omitiremos el premio del reintegro
            aciertos=0;
            bomboG.rellenarBombo();

            for (int i=0;i<jugador.lenght();i++) {
                aux = bomboG.sacarNumero();
                ganador=ganador+aux+" ";
            }
            premio= new Boleto(ganador);

            jugador.ordenarBoleto();
            premio.ordenarBoleto();

            for (int i=0;i<premio.lenght();i++) {
                for (int j = 0; j < jugador.lenght(); j++) {
                    if (premio.getNumBoleto(i) == jugador.getNumBoleto(j)) {
                        aciertos++;
                    }
                }
            }
            rondas++;
        }while(aciertos<3);
        System.out.println("Ha tardado "+rondas+" ronda/s en conseguir un premio");
        premios(aciertos, premio, jugador, reintegro);
        continuar();
        borrarPantalla();

    }
    public void juego10000(Boleto jugador, BomboG bomboG) {
        Boleto premio;
        int aux;
        String ganador;
        int aciertos;
        boolean reintegro=false;
        int contador=0;
        int premio5=0, premio4=0, premio3=0, premio2=0, premio1=0, premioEspecial=0; //He creado esta variable para
                                                                                    //despues contabilizar los premios

        do {                //Es el bucle que contara las 10000 tiradas
            ganador = "";
            aciertos = 0;
            bomboG.rellenarBombo();//Este  metodo rellenara el bombo cada vez que se reinicie la partida

            for (int i = 0; i < jugador.lenght(); i++) {
                aux = bomboG.sacarNumero();
                ganador = ganador + aux + " ";
            }
            premio = new Boleto(ganador);

            jugador.ordenarBoleto();
            premio.ordenarBoleto();

            for (int i = 0; i < premio.lenght(); i++) {
                for (int j = 0; j < jugador.lenght(); j++) {
                    if (premio.getNumBoleto(i) == jugador.getNumBoleto(j)) {
                        aciertos++;
                    }
                }
            }
            if (aciertos==3) {
                premio5++;
            }else if(aciertos==4) {
                premio4++;
            }else if(aciertos==5) {
                if(jugador.getComplementario()==premio.getComplementario()) {
                    premio2++;
                }else {
                    premio3++;
                }
            }else if(aciertos==6) {
                if(jugador.getReintegro()==premio.getReintegro()) {
                    premioEspecial++;
                }else {
                    premio1++;
                }
            }
            contador++;
        }while (contador<10001);

        System.out.println("Estadisticas para los premios conseguido en 10000 tiradas con el boleto "); //Aqui se veran los resultados
        jugador.mostrarBoleto();
        System.out.println("Premio Especial: "+premioEspecial);
        System.out.println("Premio Nº1: "+premio1);
        System.out.println("Premio Nº2: "+premio2);
        System.out.println("Premio Nº3: "+premio3);
        System.out.println("Premio Nº4: "+premio4);
        System.out.println("Premio Nº5: "+premio5);
        continuar();
        borrarPantalla();

    }
    public void juegoPremioEsp(Boleto jugador, BomboG bomboG) {
        Boleto premio;
        int aux;
        String ganador;
        int aciertos;
        int rondas=0;
        boolean reintegro=false;

        do{
            ganador="";
            aciertos=0;
            bomboG.rellenarBombo();

            for (int i=0;i<jugador.lenght();i++) {
                aux = bomboG.sacarNumero();
                ganador=ganador+aux+" ";
            }
            premio= new Boleto(ganador);

            jugador.ordenarBoleto();
            premio.ordenarBoleto();

            for (int i=0;i<premio.lenght();i++) {
                for (int j = 0; j < jugador.lenght(); j++) {
                    if (premio.getNumBoleto(i) == jugador.getNumBoleto(j)) {
                        aciertos++;
                    }
                }
            }
            rondas++;
        }while(aciertos<6 || jugador.getReintegro()!=premio.getReintegro());
        System.out.println("Ha tardado "+rondas+" ronda/s en conseguir el premio Especial");
        System.out.println("Tu boleto ");
        jugador.mostrarBoleto();
        System.out.println("Boleto ganador ");
        premio.mostrarBoleto();
        continuar();
        borrarPantalla();

    }



    public void premios(int aciertos, Boleto ganador, Boleto jugador, boolean reintegro) {
        switch (aciertos) {
            case 3:
                System.out.println("***Enhorabuena has ganado el premio de categoria Nº5***");
                System.out.println("Usted ha jugado con el boleto");
                jugador.mostrarBoleto();
                System.out.println("El gordo ha caido en ");
                ganador.mostrarBoleto();
                break;
            case 4:
                System.out.println("***Enhorabuena has ganado el premio de categoria Nº4***");
                System.out.println("Usted ha jugado con el boleto");
                jugador.mostrarBoleto();
                System.out.println("El gordo ha caido en ");
                ganador.mostrarBoleto();
                break;
            case 5:
                if (jugador.getComplementario()==ganador.getComplementario()) {
                    System.out.println("***Enhorabuena has ganado el premio de categoria Nº2***");
                    System.out.println("Usted ha jugado con el boleto");
                    jugador.mostrarBoleto();
                    System.out.println("El gordo ha caido en ");
                    ganador.mostrarBoleto();
                }else {
                    System.out.println("***Enhorabuena has ganado el premio de categoria Nº3***");
                    System.out.println("Usted ha jugado con el boleto");
                    jugador.mostrarBoleto();
                    System.out.println("El gordo ha caido en ");
                    ganador.mostrarBoleto();
                }
                break;
            case 6:
                if (reintegro) {
                    System.out.println("***Enhorabuena has ganado el premio de categoria Especial***");
                    System.out.println("Usted ha jugado con el boleto");
                    jugador.mostrarBoleto();
                    System.out.println("El gordo ha caido en ");
                    ganador.mostrarBoleto();
                }else {
                    System.out.println("***Enhorabuena has ganado el premio de categoria Nº1***");
                    System.out.println("Usted ha jugado con el boleto");
                    jugador.mostrarBoleto();
                    System.out.println("El gordo ha caido en ");
                    ganador.mostrarBoleto();
                }
            default:
                System.out.println("***Usted no ha ganado ningun premio***");
                System.out.println("Usted ha jugado con el boleto ");
                jugador.mostrarBoleto();
                System.out.println("El gordo ha caido en ");
                ganador.mostrarBoleto();
        }
    }
    public static void continuar() {
        System.out.println("Pulse intro para continuar...");
        lec.nextLine();
    }
    public static void borrarPantalla() {
        System.out.println("\u001B[2J\u001B[H");
    }
}
