package tk.robercastillo.practica2;
import tk.robercastillo.practica2.Juego.Game;
import tk.robercastillo.practica2.Utilidad.Aleatorio;

import java.util.Scanner;

public class Main {
    private static Scanner lec = new Scanner(System.in);
    public static void main(String[] args) {
        String boleto;
        int opcion;

        do {
            boleto=pedirNumero();
            System.out.println("Su boleto es "+boleto);
            continuar();
            opcion=opcionGame();
            borrarPantalla();
            Game g1 = new Game(boleto,opcion);  //Aqui sera donde ocurre to_do el juego
        }while (opcion!=0);
    }

    private static String pedirNumero() {
        int eleccion;
        String boleto = "";
        do {
            System.out.println("Como quiere conseguir su Boleto?"); //En este bloque pedimos al usuario como
            System.out.println("1. Manual\t2. Aleatorio");          //quiere obtener el boleto
            eleccion = lec.nextInt();
            lec.nextLine();
            borrarPantalla();
        }while(eleccion<1 || eleccion>2);
        switch (eleccion) {
            case 1:
                boleto = crearBoletoM();

                break;
            case 2:
                boleto = crearBoletoA();

                break;
        }
        return boleto;
    }
    public static String crearBoletoM() {       //Creacion de Boleto  Manual
        String boleto;
        System.out.println("Escribe los 6 numeros de su boleto separados de espacios");
        boleto=lec.nextLine();
        borrarPantalla();
        return boleto;
    }
    public static String crearBoletoA() {       //Creacion de boleto aleatorio
        Aleatorio al = new Aleatorio();
        String boleto;
        boleto=al.boletoAleatorio(49,1);
        return boleto;
    }
    public static int opcionGame() {    //Menú con retorno de la primitiva
        System.out.println("Indique que modalidad quiere jugar.");
        System.out.println("1. Juego unico");
        System.out.println("2. Jugar hasta obtener premio");
        System.out.println("3. Jugar hasta obtener premio (sin reintegro)");
        System.out.println("4. Ciclo de 10000 sorteos");
        System.out.println("5. Jugar hasta obtener premio de categoria especial");
        System.out.println("---------------------------------------------------");
        System.out.println("0. Salir");
        return lec.nextInt();
    }
    public static void continuar() {
        System.out.println("Pulse intro para continuar...");
        lec.nextLine();
    }
    public static void borrarPantalla() {       //borrado de pantalla
        System.out.println("\u001B[2J\u001B[H");
    }
}
