package tk.robercastillo.practica2.Objetos;

import tk.robercastillo.practica2.Utilidad.Aleatorio;

import java.util.Arrays;

public class Boleto {
    private int[] boleto;
    private int reintegro;
    private int complementario;


    public Boleto(String boleto) {
        Aleatorio a1 = new Aleatorio();
        BomboG numerosDisponibles = new BomboG();
        String[] numeros;

        boleto = boleto.trim();
        numeros = boleto.split(" ");


        this.boleto = new int[numeros.length];
        for (int i = 0; i<numeros.length;i++) {
            this.boleto[i] = Integer.parseInt(numeros[i]);
            numerosDisponibles.eliminarNumero(this.boleto[i]);
        }
        this.reintegro=a1.numeroRandom(9,0);
        this.complementario=numerosDisponibles.sacarNumero();
    }

    public int getNumBoleto(int posicion) {
        return boleto[posicion];
    }

    public int getReintegro() {
        return reintegro;
    }

    public int getComplementario() {
        return complementario;
    }


    public int lenght() {
        return boleto.length;
    }


    public void ordenarBoleto() {
        Arrays.sort(this.boleto);
    }
    public void mostrarBoleto() {
        for (int i=0;i<boleto.length;i++) {
            System.out.print(boleto[i]+" ");
        }
        System.out.print("Complementario: "+complementario+" Reintegro: "+reintegro);
        System.out.println();
    }
}
