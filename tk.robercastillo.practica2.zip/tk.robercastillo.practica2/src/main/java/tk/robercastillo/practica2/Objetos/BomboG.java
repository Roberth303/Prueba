package tk.robercastillo.practica2.Objetos;


import tk.robercastillo.practica2.Utilidad.Aleatorio;

public class BomboG {
    static final int bolasArray = 49;
    private int[] bombo;

    public BomboG() {
        bombo = new int[bolasArray];
        for (int i=0;i<bombo.length;i++) {
            bombo[i]= i + 1;
        }
    }
    public void rellenarBombo() {
        for (int i=0;i<bombo.length;i++) {
            if (bombo[i]==-1) {
                bombo[i]=i+1;
            }
        }
    }
    public int sacarNumero() {
        Aleatorio al = new Aleatorio();
        int numero;
        int posicion;
        do {
            posicion=al.numeroRandom(48,0);
            numero = bombo[posicion];
        }while(numero == -1);
        bombo[posicion] = -1;
        return numero;
    }
    public void eliminarNumero(int numSacar) {
        bombo[numSacar-1] = -1;
    }
    public int lenght() {
        return bombo.length;
    }


}
