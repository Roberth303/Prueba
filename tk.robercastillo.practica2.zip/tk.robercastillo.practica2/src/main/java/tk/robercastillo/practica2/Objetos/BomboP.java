package tk.robercastillo.practica2.Objetos;


/*public class BomboP {
    private int[] bombo;
    static final int bolasArray = 9;
    public BomboP() {
        this.bombo = new int[bolasArray];
    }
}*/

//No lo he implementado ya que no le he visto mucho uso, pero lo he dejado para hacerlo y probar en un futuro
