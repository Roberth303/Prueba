package tk.robercastillo.practica2.Utilidad;
import tk.robercastillo.practica2.Objetos.BomboG;

import java.util.Random;

public class Aleatorio {            //Metodo para sacar un boleto aleatorio
    private static Random rnd = new Random();
    public String boletoAleatorio(int max, int min) {
        BomboG numerosJ = new BomboG();             //Creamos un bombo para que al sacar un nuevo numero este no se repita
        String total = "";
        for (int i=0;i<6;i++) {
            total=total+Integer.toString(numerosJ.sacarNumero())+" ";
        }
        return total;
    }
    public int numeroRandom(int max, int min) {
        int total;
        total = rnd.nextInt(max-min+1)+min;
        return total;
    }
}
